/**
 * Created by SANSON ROOT on 3/26/2016.
 */


var r1='<div class="direct-chat-msg"> \
    <div class="direct-chat-info clearfix"> \
    <span class="direct-chat-name pull-left">' ;
var r2='</span> \
    <span class="direct-chat-timestamp pull-right">';
var r3='</span> \
    </div> \
    <img class="direct-chat-img" src="img/profile.png" \
    alt="message user image"> <div class="direct-chat-text">';
var r4='</div></div>';


var s1='<div class="direct-chat-msg right"> \
    <div class="direct-chat-info clearfix"> \
    <span class="direct-chat-name pull-right">' ;
var s2='</span> \
    <span class="direct-chat-timestamp pull-left">';
var s3='</span> \
    </div> \
    <img class="direct-chat-img" src="img/anonymous.jpg" \
    alt="message user image"> <div class="direct-chat-text">';

var s4='</div></div>';




var myname=document.getElementById("myname");
var msg=document.getElementById("message");
var chatwindow=document.getElementById("chatWindow");
var connectionState=document.getElementById("conn");
var open=false;


var socket=new WebSocket('ws://192.168.48.10:2000');
var currentTime=new Date();
var gettime=currentTime.getHours()+":"+currentTime.getMinutes()+":"+currentTime.getSeconds();
var datetime=currentTime.toDateString() + " "+gettime;
function addSenderMsg(msg){
    chatwindow.innerHTML +=s1 + myname.value + s2 + datetime + s3 + msg;
    chatwindow.scrollTop=chatwindow.scrollHeight;
}
function addReceiverMsg(msg){
    chatwindow.innerHTML +=r1 + 'sender' + r2 + datetime + r3 + msg;
    chatwindow.scrollTop=chatwindow.scrollHeight;
}
function addConMsg(msg){
    connectionState.innerHTML=msg;
}

msg.addEventListener('keypress',function(evt){
    if(evt.keyCode!=13){
        return;
    }

    evt.preventDefault();

    if(msg.value==""){
        return;
    }

    socket.send(JSON.stringify({
        msg : msg.value
        }
    ));

    addSenderMsg(msg.value);
    msg.value="";

});

socket.onopen= function () {
    open=true;
    addConMsg("Connected !");
};
socket.onclose=function(){
    open=false;
    addConMsg("Disconnected !");
};

socket.onmessage=function(evt){
    var data=JSON.parse(evt.data);
    addReceiverMsg(data.msg);
};

