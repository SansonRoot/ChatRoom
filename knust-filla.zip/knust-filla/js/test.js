

var msg=document.getElementById("messageBox");
var chatwindow=document.getElementById("chatWindow");
var open=false;


var socket=new WebSocket('ws://127.0.0.1:2000');

function addMessage(msg){
    chatwindow.innerHTML +="<p>" + msg + "</p>";
}

msg.addEventListener('keypress',function(evt){
    if(evt.keyCode!=13){
        return;
    }

    evt.preventDefault();

    if(msg.value==""){
        return;
    }

    socket.send(JSON.stringify({
            msg : msg.value
        }
    ));

    addMessage(msg.value);
    msg.value="";

});

socket.onopen= function () {
    open=true;
    addMessage("Connected !");
};
socket.onclose=function(){
    open=false;
    addMessage("Disconnected !");
};

socket.onmessage=function(evt){
    var dataf=JSON.parse(evt.data);
    addMessage(dataf.msg);
};

